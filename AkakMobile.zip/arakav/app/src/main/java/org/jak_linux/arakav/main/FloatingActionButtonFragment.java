package org.jak_linux.arakav.main;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

/**
 * Created by jak on 14/04/17.
 */

public interface FloatingActionButtonFragment {

    void setupFloatingActionButton(FloatingActionButton fab);
}
