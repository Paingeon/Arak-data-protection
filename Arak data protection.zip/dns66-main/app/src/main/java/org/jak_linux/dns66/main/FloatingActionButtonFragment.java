package org.jak_linux.dns66.main;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

/**
 * Created by jak on 14/04/17.
 */

public interface FloatingActionButtonFragment {

    void setupFloatingActionButton(FloatingActionButton fab);
}
